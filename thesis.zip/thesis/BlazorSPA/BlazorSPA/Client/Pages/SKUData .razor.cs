﻿using BlazorSPA.Shared.Models;
using Microsoft.AspNetCore.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace BlazorSPA.Client.Pages
{
    public class SKUDataModel : ComponentBase
    {
        [Inject]
        public HttpClient Http { get; set; }
        [Inject]
        public NavigationManager UrlNavigationManager { get; set; }

        [Parameter]
        public int ParamID { get; set; }
        [Parameter]
        public string Action { get; set; }

        protected List<SKU> skuList = new List<SKU>();
        protected SKU sku = new SKU();
        protected string Title { get; set; }

        protected string keyword { get; set; }



        protected override async Task OnParametersSetAsync()
        {
            if (Action == "fetch")
            {
                await FetchSKU();
                StateHasChanged();
            }
            else if (Action == "create")
            {
                Title = "Add Specs";
                sku = new SKU();
            }
            else if (ParamID != 0)
            {
                if (Action == "edit")
                {
                    Title = "Edit Specs";
                }
                else if (Action == "delete")
                {
                    Title = "Delete Specs";
                }

                sku = await Http.GetJsonAsync<SKU>("/api/SKU/Details/" + ParamID);
            }
        }

        protected async Task FetchSKU()
        {
            Title = "PC Specs";
            skuList = await Http.GetJsonAsync<List<SKU>>("api/SKU/Index");

            keyword = "";
        }
        protected async Task FetchSKUKeyword(string keyword)
        {
            Title = "PC Specs";
            skuList = await Http.GetJsonAsync<List<SKU>>("api/SKU/Keyword/"+ keyword);
        }
        protected async Task CreateSKU()
        {
            if (sku.ID != 0)
            {
                await Http.SendJsonAsync(HttpMethod.Put, "api/SKU/Edit", sku);
            }
            else
            {
                await Http.SendJsonAsync(HttpMethod.Post, "/api/SKU/Create", sku);
            }
            UrlNavigationManager.NavigateTo("/SKU/fetch");
        }

        protected async Task DeleteSKU()
        {
            await Http.DeleteAsync("api/SKU/Delete/" + ParamID);
            UrlNavigationManager.NavigateTo("/SKU/fetch");
        }

        protected void Cancel()
        {
            Title = "PC Specs";
            UrlNavigationManager.NavigateTo("/SKU/fetch");
        }
    }
}
