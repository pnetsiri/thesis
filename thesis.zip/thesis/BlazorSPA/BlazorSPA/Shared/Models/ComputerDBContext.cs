﻿using System;
using Microsoft.EntityFrameworkCore;

namespace BlazorSPA.Shared.Models
{
    public partial class ComputerDBContext : DbContext
    {
        public ComputerDBContext(DbContextOptions<ComputerDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<SKU> SKU { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<SKU>(entity =>
            {
                entity.Property(e => e.ID).HasColumnName("ID");

                entity.Property(e => e.CPU)
                    .HasColumnName("CPU")
                    .HasMaxLength(55)
                    .IsUnicode(false);

                entity.Property(e => e.GPU)
                    .HasColumnName("GPU")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PSU_Power)
                    .HasColumnName("PSU_Power")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Ram)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ID)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Storage)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.USB_Ports)
                    .HasColumnName("USB_Ports")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Weight)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
