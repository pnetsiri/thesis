﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BlazorSPA.Shared.Models
{
    public partial class SKU
    {
        public int ID { get; set; }
        [Required]
        public string Ram { get; set; }      
        public string Storage { get; set; }      
        public string USB_Ports { get; set; }        
        public string GPU { get; set; }
        public string Weight { get; set; }
        public string PSU_Power { get; set; }
        public string CPU { get; set; }
    }
}
