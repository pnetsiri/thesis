﻿using BlazorSPA.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorSPA.Server.Interface
{
    public interface ISKU
    {
        public IEnumerable<SKU> GetAllSKUs();
        public IEnumerable<SKU> GetSKUsByKeyword(string keyword);
        public void AddSKU(SKU sku);
        public void UpdateSKU(SKU sku);
        public SKU GetSKUData(int ID);
        public void DeleteSKU(int ID);
    }
}
