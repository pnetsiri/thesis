﻿using System;
using System.Collections.Generic;

namespace BlazorSPA.Server.Models
{
    public partial class SKU
    {
        public int ID { get; set; }
        public string Ram { get; set; }
        public string Storage { get; set; }
        public string USB_Ports { get; set; }
        public string GPU { get; set; }
        public string Weight { get; set; }
        public string PSU_Power { get; set; }
        public string CPU { get; set; }

    }
}
