﻿using System;
using BlazorSPA.Shared.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace BlazorSPA.Server.Models
{
    public partial class ComputerDBContext : DbContext
    {
        public ComputerDBContext()
        {
        }

        public ComputerDBContext(DbContextOptions<ComputerDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<SKU> Sku { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=ComputerDB;Data Source=localhost\\SQLEXPRESS01");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<SKU>(entity =>
            {
                entity.Property(e => e.ID).HasColumnName("ID");

                entity.Property(e => e.CPU)
                    .HasColumnName("CPU")
                    .HasMaxLength(55)
                    .IsUnicode(false);


                entity.Property(e => e.GPU)
                    .HasColumnName("GPU")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PSU_Power)
                    .HasColumnName("PSU_Power")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Ram)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ID)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Storage)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.USB_Ports)
                    .HasColumnName("USB_Ports")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Weight)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
