﻿using BlazorSPA.Server.Interface;
using BlazorSPA.Shared.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace BlazorSPA.Server.DataAccess
{
    public class SKUDataAccessLayer : ISKU
    {
        private  ComputerDBContext db;

        public SKUDataAccessLayer(ComputerDBContext _db)
        {
            db = _db;
        }

        //To Get all SKU details   
        public IEnumerable<SKU> GetAllSKUs()
        {
            try
            {
                return db.SKU.ToList();
            }
            catch
            {
                throw;
            }
        }

        public IEnumerable<SKU> GetSKUsByKeyword(string keyword)
        {
            try
            {
                return (from c in db.SKU 
                        where c.USB_Ports.ToLower().Contains(keyword.ToLower())
                        || c.GPU.Contains(keyword.ToLower())
                        || c.CPU.Contains(keyword.ToLower())
                        || c.PSU_Power.Contains(keyword.ToLower())
                        || c.Ram.Contains(keyword.ToLower())
                        || c.Storage.Contains(keyword.ToLower())
                        || c.Weight.Contains(keyword.ToLower())
                        select c).ToList(); 
                   
            }
            catch
            {
                throw;
            }
        }

        //To Add new SKU record     
        public void AddSKU(SKU sku)
        {
            try
            {
                db.SKU.Add(sku);
                db.SaveChanges();
            }
            catch
            {
                throw;
            }
        }

        //To Update the records of a SKU    
        public void UpdateSKU(SKU sku)
        {
            try
            {
                db.Entry(sku).State = EntityState.Modified;
                db.SaveChanges();
            }
            catch
            {
                throw;
            }
        }

        //Get the details of a SKU    
        public SKU GetSKUData(int ID)
        {
            try
            {
                SKU sku = db.SKU.Find(ID);
                return sku;
            }
            catch
            {
                throw;
            }
        }

        //To Delete the record of a particular SKU    
        public void DeleteSKU(int ID)
        { 
            try
            {
                SKU sku = db.SKU.Find(ID);
                db.SKU.Remove(sku);
                db.SaveChanges();
            }
            catch
            {
                throw;
            }
        }

    }
}
