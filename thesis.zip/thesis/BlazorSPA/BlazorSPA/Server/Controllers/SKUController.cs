﻿using System;
using System.Collections.Generic;
using BlazorSPA.Server.Interface;
using BlazorSPA.Shared.Models;
using Microsoft.AspNetCore.Mvc;


namespace BlazorSPA.Server.Controllers
{
    [Route("api/[controller]")]
    public class SKUController : Controller
    {

        private readonly ISKU objsku;

        public SKUController(ISKU _objsku)
        {
            objsku = _objsku;
        }

        // To Fetch all sku records
        [HttpGet]
        [Route("Index")]
        public IEnumerable<SKU> Index()
        {
            return objsku.GetAllSKUs();
        }


        // To Fetch sku records by keyword
        [HttpGet]
        [Route("Keyword/{keyword}")]
        public IEnumerable<SKU> Keyword(string keyword)
        {
            return objsku.GetSKUsByKeyword(keyword);
        }
        // To Create a new sku record
        [HttpPost]
        [Route("Create")]
        public void Create([FromBody] SKU sku)
        {
            if (ModelState.IsValid)
                objsku.AddSKU(sku);
        }

        // To fetch the details of a particular sku
        [HttpGet]
        [Route("Details/{ID}")]
        public SKU Details(int ID)
        {
            return objsku.GetSKUData(ID);
        }

        // Edit an existing employee records
        [HttpPut]
        [Route("Edit")]
        public void Edit([FromBody]SKU sku)
        {
            if (ModelState.IsValid)
                objsku.UpdateSKU(sku);
        }

        [HttpDelete]
        [Route("Delete/{ID}")]
        public void Delete(int ID)
        {
            objsku.DeleteSKU(ID);
        }
    }
}
